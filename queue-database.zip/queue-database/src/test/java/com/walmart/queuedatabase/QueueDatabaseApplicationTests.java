package com.walmart.queuedatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueueDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
